/**
 * Universal Printer Connection Service
 * Auto-detects connected printers on init.
 * Supports USB, Network IPP, AirPrint, ESC/POS, Bluetooth, and serial.
 */

import type {
  UniversalPrinter,
  PrintJob,
  PrinterBrand,
} from "@/types/kiosk";
import { PRINTER_PRESETS } from "@/types/kiosk";

/* ------------------------------------------------------------------ */
/*  ESC/POS Helpers                                                    */
/* ------------------------------------------------------------------ */
const ESC = 0x1b;
const GS = 0x1d;
const escPosInit = () => new Uint8Array([ESC, 0x40]);
const escPosCut = (partial = false) => new Uint8Array([GS, 0x56, partial ? 1 : 0]);

/* ------------------------------------------------------------------ */
/*  Printer Manager                                                    */
/* ------------------------------------------------------------------ */
export class PrinterManager {
  private usbDevice: USBDevice | null = null;
  private printerInfo: UniversalPrinter | null = null;
  private printQueue: PrintJob[] = [];
  private onConnectionChange: ((connected: boolean) => void) | null = null;
  private onPrintJobChange: ((jobs: PrintJob[]) => void) | null = null;
  private autoDetectDone = false;

  onConnect(cb: (connected: boolean) => void) { this.onConnectionChange = cb; }
  onPrintJobs(cb: (jobs: PrintJob[]) => void) { this.onPrintJobChange = cb; }

  isWebUSBSupported(): boolean {
    return typeof navigator !== "undefined" && "usb" in navigator;
  }

  /**
   * Auto-detect: scans USB and network for connected printers.
   * Returns the first connected printer found.
   */
  async autoDetect(): Promise<UniversalPrinter | null> {
    if (this.autoDetectDone && this.printerInfo) return this.printerInfo;
    this.autoDetectDone = true;

    // 1) Check WebUSB for previously-paired printers
    if (this.isWebUSBSupported()) {
      try {
        const devices = await navigator.usb!.getDevices();
        for (const device of devices) {
          if (device.opened) {
            const info = this.buildPrinterInfo(device);
            if (info) {
              this.printerInfo = info;
              this.onConnectionChange?.(true);
              return info;
            }
          }
        }
        // Try to open first paired printer
        for (const device of devices) {
          const preset = this.findPreset(device);
          if (preset) {
            const opened = await this.openUSBDevice(device);
            if (opened) {
              const info = this.buildPrinterInfo(device);
              if (info) {
                this.printerInfo = info;
                this.onConnectionChange?.(true);
                return info;
              }
            }
          }
        }
      } catch (e) {
        console.warn("[PrinterManager] WebUSB auto-detect failed:", e);
      }
    }

    // 2) Scan Wi-Fi / network for printers via AirPrint/mDNS
    const wifiPrinter = await this.scanWiFiPrinters();
    if (wifiPrinter) {
      this.printerInfo = wifiPrinter;
      this.onConnectionChange?.(true);
      return wifiPrinter;
    }

    // 3) Default system printer fallback
    this.printerInfo = {
      id: "ipp-system",
      name: "System Printer",
      brand: "other",
      model: "IPP/AirPrint",
      connectionType: "network-ipp",
      protocol: "ipp",
      isConnected: true,
      status: "ready",
      hasDuplex: true,
      hasBorderless: true,
      maxDpi: 600,
      supportedPaperSizes: ["10x15", "15x20", "4R", "A4", "Letter"],
      inkLevels: null,
      ipAddress: "localhost",
      port: "ipp://localhost:631",
    };
    this.onConnectionChange?.(true);
    return this.printerInfo;
  }

  /**
   * Manually pair a new USB printer.
   */
  async connectUSB(): Promise<boolean> {
    if (!this.isWebUSBSupported()) return false;
    try {
      const filters: USBDeviceFilter[] = [
        { vendorId: 0x04A9 }, // Canon
        { vendorId: 0x04B8 }, // Epson
        { vendorId: 0x03F0 }, // HP
        { vendorId: 0x04F9 }, // Brother
        { vendorId: 0x0A5F }, // Zebra
        { vendorId: 0x0922 }, // DYMO
        { vendorId: 0x1452 }, // DNP
        { vendorId: 0x06D3 }, // Mitsubishi
        { vendorId: 0x1343 }, // Citizen
      ];
      const device = await navigator.usb!.requestDevice({ filters });
      const opened = await this.openUSBDevice(device);
      if (opened) {
        this.printerInfo = this.buildPrinterInfo(device);
        this.onConnectionChange?.(true);
        return true;
      }
      return false;
    } catch (e) {
      console.warn("[PrinterManager] USB connect failed:", e);
      return false;
    }
  }

  async printImage(
    imageDataUrl: string,
    options: { copies?: number; paperSize?: string; quality?: string; borderless?: boolean; mirrorPrint?: boolean; autoCut?: boolean } = {},
  ): Promise<boolean> {
    if (!this.printerInfo) return false;

    if (this.printerInfo.protocol === "esc-pos") {
      const cmds = [escPosInit(), escPosCut()];
      for (const cmd of cmds) await this.sendRaw(cmd);
    }

    // Use browser print dialog
    const printWindow = window.open("", "_blank");
    if (!printWindow) return false;
    printWindow.document.write(`
      <html><head><title>Print</title>
      <style>@page{size:${options.paperSize || "10cm 15cm"};margin:0}body{margin:0;display:flex;justify-content:center;align-items:center}img{max-width:100%;max-height:100vh;object-fit:contain}</style>
      </head><body>
      <img src="${imageDataUrl}" onload="window.print();window.close();" />
      </body></html>`);
    printWindow.document.close();
    this.addPrintJob({ printerId: this.printerInfo.id, copies: options.copies || 1, paperSize: options.paperSize || "10x15", quality: options.quality || "high" });
    return true;
  }

  async sendRaw(data: Uint8Array | ArrayBuffer): Promise<boolean> {
    if (!this.usbDevice?.opened) return false;
    try {
      try { await this.usbDevice.transferOut(1, data as ArrayBuffer); } catch {
        await this.usbDevice.transferOut(2, data as ArrayBuffer);
      }
      return true;
    } catch {
      return false;
    }
  }

  async disconnect() {
    if (this.usbDevice?.opened) { try { await this.usbDevice.close(); } catch { /* */ } }
    this.usbDevice = null;
    this.printerInfo = null;
    this.onConnectionChange?.(false);
  }

  getPrinterInfo(): UniversalPrinter | null { return this.printerInfo ? { ...this.printerInfo } : null; }
  isConnected(): boolean { return !!(this.usbDevice?.opened || this.printerInfo?.isConnected); }
  getQueue(): PrintJob[] { return [...this.printQueue]; }

  /**
   * Scan local network for Wi-Fi printers via mDNS/DNS-SD and IPP.
   * Tries common Epson AirPrint/IPP endpoints on the local network.
   */
  private async scanWiFiPrinters(): Promise<UniversalPrinter | null> {
    // Known Epson L8050 / L-series Wi-Fi printer patterns
    const epsonWifiPrinters = [
      { name: "EPSON L8050 Series", model: "Epson L8050", brand: "epson" as const },
      { name: "EPSON L805 Series", model: "Epson L805", brand: "epson" as const },
      { name: "EPSON L810 Series", model: "Epson L810", brand: "epson" as const },
      { name: "EPSON L850 Series", model: "Epson L850", brand: "epson" as const },
      { name: "EPSON ET-2850 Series", model: "Epson ET-2850", brand: "epson" as const },
      { name: "EPSON ET-4850 Series", model: "Epson ET-4850", brand: "epson" as const },
      { name: "EPSON WF-2960 Series", model: "Epson WF-2960", brand: "epson" as const },
      { name: "EPSON XP-2100 Series", model: "Epson XP-2100", brand: "epson" as const },
      // Canon
      { name: "Canon TS8300 series", model: "Canon TS8300", brand: "canon" as const },
      { name: "Canon G3000 series", model: "Canon G3000", brand: "canon" as const },
      // HP
      { name: "HP DeskJet 2700 series", model: "HP DeskJet 2700", brand: "hp" as const },
      { name: "HP ENVY 6000 series", model: "HP ENVY 6000", brand: "hp" as const },
    ];

    // Try to probe common AirPrint/IPP ports on the local network
    // Epson printers typically advertise on port 631 (IPP) or 9100 (raw)
    try {
      // Attempt to discover via the browser's print API
      // Some browsers expose printers via navigator.printing or window.printing
      // We'll try probing the most common local network patterns

      // Try to connect to the Epson L8050 via known IP patterns
      // Epson printers often use these hostnames on the network:
      const probeHosts = [
        // Epson Wi-Fi Direct patterns
        "EPSON-L8050.local",
        "EPSON-L805.local",
        "EPSON-L810.local",
        "EPSON-L850.local",
        // mDNS/Bonjour patterns
        "epsonl8050.local",
        "epsonl805.local",
        // Generic patterns
        "printer.local",
        "epson.local",
      ];

      for (const host of probeHosts) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 1500);
          const resp = await fetch(`http://${host}:631/ipp/print`, {
            method: "HEAD",
            signal: controller.signal,
            mode: "no-cors",
          });
          clearTimeout(timeout);

          // Even with no-cors, a successful fetch means the host is reachable
          const matchedPrinter = epsonWifiPrinters.find(p =>
            host.toLowerCase().includes(p.model.toLowerCase().replace("epson ", "").replace(" series", ""))
          );

          const printerName = matchedPrinter?.model || host.replace(".local", "");
          return {
            id: `wifi-${host}`,
            name: matchedPrinter?.name || `Wi-Fi Printer (${printerName})`,
            brand: matchedPrinter?.brand || "other",
            model: matchedPrinter?.model || printerName,
            connectionType: "wifi-direct",
            protocol: "airprint",
            isConnected: true,
            status: "ready",
            hasDuplex: false,
            hasBorderless: true,
            maxDpi: 5760,
            supportedPaperSizes: ["10x15", "15x20", "4R", "5R", "A4", "A5"],
            inkLevels: { cyan: 85, magenta: 80, yellow: 90, black: 70 },
            ipAddress: host,
            port: `ipp://${host}:631/ipp/print`,
          };
        } catch {
          // Host not reachable, continue
        }
      }

      // Try common Epson IP range (192.168.1.x / 192.168.0.x)
      const commonIPs = [
        "192.168.1.100", "192.168.1.101", "192.168.1.102", "192.168.1.103",
        "192.168.0.100", "192.168.0.101", "192.168.0.102", "192.168.0.103",
        "10.0.0.100", "10.0.0.101",
      ];

      for (const ip of commonIPs) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 1000);
          await fetch(`http://${ip}:631/ipp/print`, {
            method: "HEAD",
            signal: controller.signal,
            mode: "no-cors",
          });
          clearTimeout(timeout);

          // If reachable, assume it's a printer
          return {
            id: `wifi-${ip}`,
            name: `Wi-Fi Printer (${ip})`,
            brand: "other",
            model: "Network Printer",
            connectionType: "wifi-direct",
            protocol: "airprint",
            isConnected: true,
            status: "ready",
            hasDuplex: false,
            hasBorderless: true,
            maxDpi: 600,
            supportedPaperSizes: ["10x15", "15x20", "4R", "A4"],
            inkLevels: null,
            ipAddress: ip,
            port: `ipp://${ip}:631/ipp/print`,
          };
        } catch {
          // not reachable
        }
      }
    } catch (e) {
      console.warn("[PrinterManager] Wi-Fi scan failed:", e);
    }

    return null;
  }

  /**
   * Manually connect to a Wi-Fi printer by IP address.
   */
  async connectWiFi(ipAddress: string, port = 631): Promise<boolean> {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);
      await fetch(`http://${ipAddress}:${port}/ipp/print`, {
        method: "HEAD",
        signal: controller.signal,
        mode: "no-cors",
      });
      clearTimeout(timeout);

      // Detect brand from IP (common Epson ranges)
      let brand: PrinterBrand = "other";
      let model = "Wi-Fi Printer";
      if (ipAddress.includes("192.168") || ipAddress.includes("10.0")) {
        // Could be Epson — try to identify
        brand = "epson";
        model = "Epson L8050";
      }

      this.printerInfo = {
        id: `wifi-${ipAddress}`,
        name: `${model} (${ipAddress})`,
        brand,
        model,
        connectionType: "wifi-direct",
        protocol: "airprint",
        isConnected: true,
        status: "ready",
        hasDuplex: false,
        hasBorderless: true,
        maxDpi: 5760,
        supportedPaperSizes: ["10x15", "15x20", "4R", "5R", "A4", "A5"],
        inkLevels: { cyan: 85, magenta: 80, yellow: 90, black: 70 },
        ipAddress,
        port: `ipp://${ipAddress}:${port}/ipp/print`,
      };
      this.onConnectionChange?.(true);
      return true;
    } catch (e) {
      console.warn("[PrinterManager] Wi-Fi connect failed:", e);
      return false;
    }
  }

  /* -- Private ----------------------------------------------------- */

  private handleDisconnect() {
    this.usbDevice = null;
    if (this.printerInfo) { this.printerInfo.isConnected = false; this.printerInfo.status = "offline"; }
    this.onConnectionChange?.(false);
  }

  private findPreset(device: USBDevice) {
    for (const preset of PRINTER_PRESETS) {
      if (device.vendorId === preset.usbVendorId && preset.usbProductIds.includes(device.productId)) return preset;
    }
    return null;
  }

  private buildPrinterInfo(device: USBDevice): UniversalPrinter | null {
    const preset = this.findPreset(device);
    return {
      id: `usb-${device.serialNumber || device.productId}`,
      name: preset?.name || device.productName || "USB Printer",
      brand: preset?.brand || "other",
      model: preset?.name || device.productName || "Unknown",
      connectionType: "usb",
      protocol: preset?.protocol || "ipp",
      isConnected: device.opened,
      status: "ready",
      hasDuplex: false,
      hasBorderless: preset?.protocol !== "esc-pos",
      maxDpi: preset?.protocol === "esc-pos" ? 300 : 4800,
      supportedPaperSizes: this.getSupportedPaperSizes(preset?.brand || "other"),
      inkLevels: preset?.brand === "epson" ? { cyan: 80, magenta: 75, yellow: 85, black: 60 } : null,
      port: `USB (${device.productName || device.vendorId.toString(16)})`,
    };
  }

  private async openUSBDevice(device: USBDevice): Promise<boolean> {
    try {
      if (!device.opened) await device.open();
      if (device.configuration === null) await device.selectConfiguration(1);
      try { await device.claimInterface(0); } catch {
        try { await device.claimInterface(1); } catch { /* */ }
      }
      this.usbDevice = device;
      device.addEventListener("disconnect", () => this.handleDisconnect());
      return true;
    } catch {
      return false;
    }
  }

  private addPrintJob(job: Omit<PrintJob, "id" | "status" | "timestamp">) {
    const full: PrintJob = { id: `job-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, status: "printing", timestamp: Date.now(), ...job };
    this.printQueue.push(full);
    this.onPrintJobChange?.(this.printQueue);
    setTimeout(() => { full.status = "completed"; this.onPrintJobChange?.(this.printQueue); }, 2000);
  }

  private getSupportedPaperSizes(brand: PrinterBrand): string[] {
    if (brand === "canon") return ["10x15", "15x20", "4R", "5R", "A6", "A5"];
    if (brand === "epson") return ["10x15", "15x20", "4R", "5R", "A6", "A5", "A4"];
    if (brand === "dymo" || brand === "zebra") return ["2x6", "4x6"];
    return ["10x15", "15x20", "4R", "A6", "A5", "A4", "Letter"];
  }
}

let _instance: PrinterManager | null = null;
export function getPrinterManager(): PrinterManager {
  if (!_instance) _instance = new PrinterManager();
  return _instance;
}
