import React, { useRef, useCallback, useState } from "react";
import { motion } from "framer-motion";
import { Download, RefreshCw, ChevronLeft, Check, Printer } from "lucide-react";
import type { FrameTemplate, EditorElement } from "@/types/kiosk";
import { getPrinterManager } from "@/services/printer";

/* ------------------------------------------------------------------ */
/*  Frame slot positions for each layout type (4R portrait 472×709)    */
/* ------------------------------------------------------------------ */
const SLOT_POSITIONS: Record<string, Array<{ x: number; y: number; w: number; h: number }>> = {
  "layout-elegant": [
    { x: 28, y: 60, w: 200, h: 280 },
    { x: 244, y: 60, w: 200, h: 280 },
    { x: 28, y: 356, w: 200, h: 280 },
    { x: 244, y: 356, w: 200, h: 280 },
  ],
  "layout-minimal": [
    { x: 20, y: 50, w: 206, h: 290 },
    { x: 246, y: 50, w: 206, h: 290 },
    { x: 20, y: 356, w: 206, h: 290 },
    { x: 246, y: 356, w: 206, h: 290 },
  ],
  "layout-floral": [
    { x: 24, y: 55, w: 202, h: 285 },
    { x: 246, y: 55, w: 202, h: 285 },
    { x: 24, y: 350, w: 202, h: 285 },
    { x: 246, y: 350, w: 202, h: 285 },
  ],
  "layout-retro": [
    { x: 16, y: 50, w: 440, h: 180 },
    { x: 16, y: 240, w: 440, h: 180 },
    { x: 16, y: 430, w: 440, h: 180 },
  ],
  "layout-polaroid": [
    { x: 40, y: 30, w: 392, h: 210 },
    { x: 40, y: 250, w: 392, h: 210 },
    { x: 40, y: 470, w: 392, h: 210 },
  ],
  "layout-cinema": [
    { x: 20, y: 60, w: 432, h: 240 },
    { x: 20, y: 400, w: 432, h: 240 },
  ],
  "layout-modern": [
    { x: 16, y: 16, w: 260, h: 300 },
    { x: 286, y: 16, w: 176, h: 144 },
    { x: 286, y: 170, w: 176, h: 146 },
    { x: 16, y: 326, w: 446, h: 350 },
  ],
  "layout-romantic": [
    { x: 20, y: 50, w: 432, h: 180 },
    { x: 20, y: 240, w: 432, h: 180 },
    { x: 20, y: 430, w: 432, h: 180 },
  ],
  "layout-bold": [
    { x: 16, y: 16, w: 210, h: 310 },
    { x: 246, y: 16, w: 210, h: 310 },
    { x: 16, y: 346, w: 210, h: 310 },
    { x: 246, y: 346, w: 210, h: 310 },
  ],
  "none": [],
};

/* ------------------------------------------------------------------ */
/*  Theme-aware color palettes                                         */
/* ------------------------------------------------------------------ */
const THEME_COLORS: Record<string, { bg: string; frame: string; accent: string; text: string; textSub: string }> = {
  dark: { bg: "#0a0a0a", frame: "#1a1a1a", accent: "#888888", text: "#ededed", textSub: "#666666" },
  light: { bg: "#fafafa", frame: "#ffffff", accent: "#111111", text: "#111111", textSub: "#999999" },
  warm: { bg: "#1a1410", frame: "#2a2018", accent: "#d4a574", text: "#e8d5c0", textSub: "#8a7a6a" },
};

/* ------------------------------------------------------------------ */
/*  Draw editorElements directly onto canvas (synchronized with editor)*/
/* ------------------------------------------------------------------ */
function drawEditorElementsToCanvas(
  ctx: CanvasRenderingContext2D,
  elements: EditorElement[],
  photos: string[],
  photoImages: HTMLImageElement[],
  canvasW: number,
  canvasH: number,
) {
  const scale = canvasW / 472;
  const sorted = [...elements].filter(e => e.visible).sort((a, b) => a.zIndex - b.zIndex);

  // Clear
  ctx.clearRect(0, 0, canvasW, canvasH);

  for (const el of sorted) {
    const x = el.x * scale;
    const y = el.y * scale;
    const w = el.w * scale;
    const h = el.h * scale;
    const r = el.rotation;

    ctx.save();
    if (r) {
      ctx.translate(x + w / 2, y + h / 2);
      ctx.rotate((r * Math.PI) / 180);
      ctx.translate(-(x + w / 2), -(y + h / 2));
    }

    switch (el.type) {
      case "background":
        ctx.fillStyle = el.bgColor || "#111";
        ctx.fillRect(0, 0, canvasW, canvasH);
        break;
      case "photo": {
        const slotX = x, slotY = y, slotW = w, slotH = h;
        const pi = el.photoIndex ?? 0;
        const img = photoImages[pi];
        if (img && img.complete && img.naturalWidth > 0) {
          const imgRatio = img.naturalWidth / img.naturalHeight;
          const slotRatio = slotW / slotH;
          let drawW: number, drawH: number, offX: number, offY: number;
          if (imgRatio > slotRatio) {
            drawH = slotH; drawW = slotH * imgRatio;
            offX = slotX - (drawW - slotW) / 2; offY = slotY;
          } else {
            drawW = slotW; drawH = slotW / imgRatio;
            offX = slotX; offY = slotY - (drawH - slotH) / 2;
          }
          ctx.beginPath();
          ctx.rect(slotX, slotY, slotW, slotH);
          ctx.clip();
          ctx.drawImage(img, offX, offY, drawW, drawH);
        } else {
          ctx.fillStyle = el.bgColor || "#333";
          ctx.fillRect(slotX, slotY, slotW, slotH);
        }
        break;
      }
      case "text":
        ctx.fillStyle = el.color || "#aaa";
        ctx.font = `${(el.fontSize || 12) * scale}px ${el.fontFamily || "sans-serif"}`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(el.text || "", x + w / 2, y + h / 2);
        break;
      case "shape":
        if (el.bgColor && el.bgColor !== "transparent") {
          ctx.fillStyle = el.bgColor;
          const br = (el.borderRadius || 0) * scale;
          if (br > 0) {
            ctx.beginPath();
            ctx.roundRect(x, y, w, h, br);
            ctx.fill();
          } else {
            ctx.fillRect(x, y, w, h);
          }
        }
        if (el.strokeColor) {
          ctx.strokeStyle = el.strokeColor;
          ctx.lineWidth = (el.strokeWidth || 1) * scale;
          ctx.strokeRect(x, y, w, h);
        }
        break;
      case "image":
        if (el.imageData) {
          const img2 = new Image();
          img2.src = el.imageData;
          if (img2.complete) {
            ctx.drawImage(img2, x, y, w, h);
          }
        }
        break;
    }
    ctx.restore();
  }
}

/* ------------------------------------------------------------------ */
/*  Draw a single frame layout onto a canvas                          */
/* ------------------------------------------------------------------ */
function drawFrameToCanvas(
  ctx: CanvasRenderingContext2D,
  template: FrameTemplate,
  photos: string[],
  theme: string,
  photoImages: HTMLImageElement[],
  canvasW: number,
  canvasH: number,
) {
  const colors = THEME_COLORS[theme] || THEME_COLORS.dark;
  const scale = canvasW / 472;

  // Background
  ctx.fillStyle = colors.bg;
  ctx.fillRect(0, 0, canvasW, canvasH);

  const layout = template.layoutType;

  if (layout === "layout-elegant") {
    // Gold border frame
    ctx.strokeStyle = "#d4a574";
    ctx.lineWidth = 3 * scale;
    ctx.strokeRect(8 * scale, 8 * scale, (canvasW - 16), (canvasH - 16));
    ctx.lineWidth = 1 * scale;
    ctx.strokeRect(14 * scale, 14 * scale, (canvasW - 28), (canvasH - 28));
    // Corner dots
    [16, canvasW - 16, 16, canvasW - 16].forEach((_, i) => {
      const cx = i < 2 ? 16 * scale : (canvasW - 16 * scale);
      const cy = i % 2 === 0 ? 16 * scale : (canvasH - 16 * scale);
      ctx.fillStyle = "#d4a574";
      ctx.beginPath(); ctx.arc(cx, cy, 4 * scale, 0, Math.PI * 2); ctx.fill();
    });
    // Title
    ctx.fillStyle = "#2a2520";
    ctx.fillRect(28 * scale, 24 * scale, canvasW - 56 * scale, 28 * scale);
    ctx.fillStyle = "#d4a574";
    ctx.font = `italic ${12 * scale}px serif`;
    ctx.textAlign = "center";
    ctx.fillText("Groom & Bride", canvasW / 2, 44 * scale);
  } else if (layout === "layout-minimal") {
    ctx.strokeStyle = "#555555";
    ctx.lineWidth = 1 * scale;
    ctx.strokeRect(10 * scale, 10 * scale, canvasW - 20 * scale, canvasH - 20 * scale);
    ctx.fillStyle = "#aaaaaa";
    ctx.font = `${11 * scale}px sans-serif`;
    ctx.textAlign = "center";
    ctx.letterSpacing = "4px";
    ctx.fillText("WEDDING", canvasW / 2, 36 * scale);
  } else if (layout === "layout-floral") {
    ctx.fillStyle = "#2a1f25";
    ctx.fillRect(6 * scale, 6 * scale, canvasW - 12 * scale, canvasH - 12 * scale);
    // Flower corners
    [0, 1, 2, 3].forEach(i => {
      const cx = i % 2 === 0 ? 18 * scale : (canvasW - 18 * scale);
      const cy = i < 2 ? 18 * scale : (canvasH - 18 * scale);
      ctx.fillStyle = "rgba(196,122,138,0.4)";
      ctx.beginPath(); ctx.arc(cx, cy, 8 * scale, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "rgba(232,160,176,0.6)";
      ctx.beginPath(); ctx.arc(cx, cy, 4 * scale, 0, Math.PI * 2); ctx.fill();
    });
    ctx.fillStyle = "#c47a8a";
    ctx.font = `italic ${11 * scale}px serif`;
    ctx.textAlign = "center";
    ctx.fillText("Groom & Bride", canvasW / 2, 40 * scale);
  } else if (layout === "layout-retro") {
    ctx.fillStyle = "#2a2218";
    ctx.fillRect(0, 0, canvasW, canvasH);
    ctx.fillStyle = "#3a3020";
    ctx.fillRect(14 * scale, 14 * scale, canvasW - 28 * scale, 28 * scale);
    ctx.fillStyle = "#c4a060";
    ctx.font = `monospace ${9 * scale}px`;
    ctx.textAlign = "center";
    ctx.fillText("ROLL #001", canvasW / 2, 34 * scale);
  } else if (layout === "layout-polaroid") {
    ctx.fillStyle = "#f0ece8";
    ctx.fillRect(0, 0, canvasW, canvasH);
  } else if (layout === "layout-cinema") {
    ctx.fillStyle = "#0a0a0a";
    ctx.fillRect(0, 0, canvasW, canvasH);
    ctx.fillStyle = "#ffffff";
    ctx.font = `bold ${12 * scale}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText("NOW SHOWING", canvasW / 2, 44 * scale);
    ctx.fillStyle = "#c44040";
    ctx.fillRect(20 * scale, 52 * scale, canvasW - 40 * scale, 1.5 * scale);
  } else if (layout === "layout-modern") {
    ctx.fillStyle = "#111111";
    ctx.fillRect(0, 0, canvasW, canvasH);
    ctx.fillStyle = "#d44040";
    ctx.fillRect(280 * scale, 16 * scale, 176 * scale, 144 * scale);
    ctx.globalAlpha = 0.5;
    ctx.fillRect(280 * scale, 346 * scale, 176 * scale, 350 * scale);
    ctx.globalAlpha = 1;
    ctx.fillStyle = "#666666";
    ctx.font = `bold ${10 * scale}px sans-serif`;
    ctx.textAlign = "left";
    ctx.fillText("MODERN", 20 * scale, canvasH - 18 * scale);
  } else if (layout === "layout-romantic") {
    ctx.fillStyle = "#2a1a20";
    ctx.fillRect(0, 0, canvasW, canvasH);
    ctx.fillStyle = "#e06080";
    ctx.font = `${14 * scale}px serif`;
    ctx.textAlign = "left";
    ctx.fillText("♥", 24 * scale, 32 * scale);
    ctx.textAlign = "center";
    ctx.font = `italic ${11 * scale}px serif`;
    ctx.fillText("Together Forever", canvasW / 2, 40 * scale);
  } else if (layout === "layout-bold") {
    ctx.fillStyle = "#ffffff";
    ctx.fillRect(0, 0, canvasW, canvasH);
    ctx.fillStyle = "#000000";
    ctx.fillRect(4 * scale, 4 * scale, canvasW - 8 * scale, canvasH - 8 * scale);
    ctx.fillStyle = "#ffffff";
    ctx.font = `900 ${14 * scale}px sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText("BOLD", canvasW / 2, canvasH - 16 * scale);
  }

  // Draw photos into slots
  const slots = SLOT_POSITIONS[layout] || [];
  slots.forEach((slot, i) => {
    if (i >= photos.length || i >= photoImages.length) return;
    const img = photoImages[i];
    if (!img || !img.complete) return;

    const sx = slot.x * scale;
    const sy = slot.y * scale;
    const sw = slot.w * scale;
    const sh = slot.h * scale;

    // Cover-fit the photo
    const imgRatio = img.naturalWidth / img.naturalHeight;
    const slotRatio = sw / sh;
    let drawW: number, drawH: number, offsetX: number, offsetY: number;

    if (imgRatio > slotRatio) {
      drawH = sh;
      drawW = sh * imgRatio;
      offsetX = sx - (drawW - sw) / 2;
      offsetY = sy;
    } else {
      drawW = sw;
      drawH = sw / imgRatio;
      offsetX = sx;
      offsetY = sy - (drawH - sh) / 2;
    }

    ctx.save();
    ctx.beginPath();
    ctx.rect(sx, sy, sw, sh);
    ctx.clip();
    ctx.drawImage(img, offsetX, offsetY, drawW, drawH);
    ctx.restore();
  });
}

/* ------------------------------------------------------------------ */
/*  Main Compositor Component                                          */
/* ------------------------------------------------------------------ */
interface FrameCompositorProps {
  template: FrameTemplate;
  photos: string[];
  theme: string;
  onBack: () => void;
  onNext: () => void;
}

/* ------------------------------------------------------------------ */
/*  Crop a photo data URL to match a target aspect ratio              */
/* ------------------------------------------------------------------ */
function cropPhotoToAspect(dataUrl: string, targetW: number, targetH: number): Promise<string> {
  return new Promise((resolve) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = targetW;
      canvas.height = targetH;
      const ctx = canvas.getContext("2d");
      if (!ctx) { resolve(dataUrl); return; }

      const imgRatio = img.naturalWidth / img.naturalHeight;
      const slotRatio = targetW / targetH;
      let sx: number, sy: number, sw: number, sh: number;

      if (imgRatio > slotRatio) {
        // Image is wider — crop sides (center crop)
        sh = img.naturalHeight;
        sw = sh * slotRatio;
        sx = (img.naturalWidth - sw) / 2;
        sy = 0;
      } else {
        // Image is taller — crop top/bottom (center crop)
        sw = img.naturalWidth;
        sh = sw / slotRatio;
        sx = 0;
        sy = (img.naturalHeight - sh) / 2;
      }

      ctx.drawImage(img, sx, sy, sw, sh, 0, 0, targetW, targetH);
      resolve(canvas.toDataURL("image/jpeg", 0.95));
    };
    img.onerror = () => resolve(dataUrl);
    img.src = dataUrl;
  });
}

export default function FrameCompositor({ template, photos, theme, onBack, onNext }: FrameCompositorProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [downloaded, setDownloaded] = useState(false);
  const [autoSaved, setAutoSaved] = useState(false);
  const [printing, setPrinting] = useState(false);
  const [printed, setPrinted] = useState(false);
  const photoImagesRef = useRef<HTMLImageElement[]>([]);
  const croppedPhotosRef = useRef<string[]>([]);

  const n = template.poses;
  const canvasW = 472;
  const canvasH = 709;
  const layout = template.layoutType;
  const slots = SLOT_POSITIONS[layout] || [];
  const colors = THEME_COLORS[theme] || THEME_COLORS.dark;

  const [imagesLoaded, setImagesLoaded] = useState(0);

  // Crop photos to match each slot's aspect ratio
  React.useEffect(() => {
    const cropAll = async () => {
      const cropped: string[] = [];
      for (let i = 0; i < photos.length; i++) {
        if (!photos[i]) { cropped.push(""); continue; }
        const slot = slots[i] || slots[0];
        if (slot) {
          cropped.push(await cropPhotoToAspect(photos[i], slot.w, slot.h));
        } else {
          cropped.push(photos[i]);
        }
      }
      croppedPhotosRef.current = cropped;
    };
    cropAll();
  }, [photos, slots]);

  // Preload cropped photos
  React.useEffect(() => {
    const cropped = croppedPhotosRef.current.length > 0 ? croppedPhotosRef.current : photos;
    const imgs: HTMLImageElement[] = [];
    let loadedCount = 0;
    const total = cropped.filter(Boolean).length;
    if (total === 0) { photoImagesRef.current = []; setImagesLoaded(0); return; }
    cropped.forEach((src, i) => {
      if (!src) { imgs[i] = null as unknown as HTMLImageElement; return; }
      const img = new Image();
      img.onload = () => {
        loadedCount++;
        photoImagesRef.current[i] = img;
        if (loadedCount >= total) setImagesLoaded(loadedCount);
      };
      img.onerror = () => {
        loadedCount++;
        if (loadedCount >= total) setImagesLoaded(loadedCount);
      };
      img.src = src;
      imgs[i] = img;
    });
    photoImagesRef.current = imgs;
  }, [croppedPhotosRef.current.length]); // eslint-disable-line

  // Draw preview on canvas
  const drawPreview = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    template.editorElements && template.editorElements.length > 0 ? drawEditorElementsToCanvas(ctx, template.editorElements, photos, photoImagesRef.current, canvasW, canvasH) : drawFrameToCanvas(ctx, template, photos, theme, photoImagesRef.current, canvasW, canvasH);
  }, [template, photos, theme]);

  // Draw after images finish loading
  React.useEffect(() => { if (imagesLoaded > 0) drawPreview(); }, [imagesLoaded, drawPreview]);
  // Also draw immediately for frame preview (without photos)
  React.useEffect(() => { drawPreview(); }, [drawPreview]);

  // Auto-save to local storage after photos are composited
  React.useEffect(() => {
    if (imagesLoaded > 0 && !autoSaved) {
      const timer = setTimeout(() => {
        const hiRes = document.createElement("canvas");
        hiRes.width = canvasW * 2;
        hiRes.height = canvasH * 2;
        const ctx = hiRes.getContext("2d");
        if (!ctx) return;
        template.editorElements && template.editorElements.length > 0 ? drawEditorElementsToCanvas(ctx, template.editorElements, photos, photoImagesRef.current, canvasW * 2, canvasH * 2) : drawFrameToCanvas(ctx, template, photos, theme, photoImagesRef.current, canvasW * 2, canvasH * 2);
        setTimeout(() => {
          hiRes.toBlob((blob) => {
            if (!blob) return;
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url;
            a.download = `${template.name.replace(/\s+/g, "_")}_${Date.now()}.jpg`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            setAutoSaved(true);
          }, "image/jpeg", 0.95);
        }, 200);
      }, 800); // short delay so canvas is rendered first
      return () => clearTimeout(timer);
    }
  }, [imagesLoaded, autoSaved, template, photos, theme]);

  // Download the composited image
  const handleDownload = useCallback(() => {
    setDownloading(true);
    const hiRes = document.createElement("canvas");
    hiRes.width = canvasW * 2;
    hiRes.height = canvasH * 2;
    const ctx = hiRes.getContext("2d");
    if (!ctx) { setDownloading(false); return; }

    template.editorElements && template.editorElements.length > 0 ? drawEditorElementsToCanvas(ctx, template.editorElements, photos, photoImagesRef.current, canvasW * 2, canvasH * 2) : drawFrameToCanvas(ctx, template, photos, theme, photoImagesRef.current, canvasW * 2, canvasH * 2);

    setTimeout(() => {
      hiRes.toBlob((blob) => {
        if (!blob) { setDownloading(false); return; }
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${template.name.replace(/\s+/g, "_")}_${Date.now()}.jpg`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        setDownloading(false);
        setDownloaded(true);
        setTimeout(() => setDownloaded(false), 3000);
      }, "image/jpeg", 0.95);
    }, 100);
  }, [template, photos, theme]);

  // Print the composited photo
  const handlePrint = useCallback(() => {
    setPrinting(true);
    const hiRes = document.createElement("canvas");
    hiRes.width = canvasW * 2;
    hiRes.height = canvasH * 2;
    const ctx = hiRes.getContext("2d");
    if (!ctx) { setPrinting(false); return; }
    template.editorElements && template.editorElements.length > 0 ? drawEditorElementsToCanvas(ctx, template.editorElements, photos, photoImagesRef.current, canvasW * 2, canvasH * 2) : drawFrameToCanvas(ctx, template, photos, theme, photoImagesRef.current, canvasW * 2, canvasH * 2);
    setTimeout(() => {
      const dataUrl = hiRes.toDataURL("image/jpeg", 0.95);
      const mgr = getPrinterManager();
      mgr.printImage(dataUrl, { paperSize: "10x15", quality: "high", borderless: true }).then(ok => {
        setPrinting(false);
        if (ok) { setPrinted(true); setTimeout(() => setPrinted(false), 3000); }
      }).catch(() => setPrinting(false));
    }, 100);
  }, [template, photos, theme]);

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="min-h-screen flex flex-col bg-background text-foreground">
      {/* Header */}
      <div className="px-6 py-4 flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors">
          <ChevronLeft className="h-4 w-4" /><span>Kembali</span>
        </button>
        <h2 className="text-sm font-medium tracking-widest uppercase text-muted-foreground">Hasil Foto</h2>
        <button onClick={onNext} className="text-xs tracking-wide uppercase bg-foreground text-primary-foreground px-4 py-1.5 rounded-full">Selesai</button>
      </div>

      {/* Content — centered large canvas */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 pb-6">

        {/* Canvas preview — large, centered */}
        <div className="relative mb-6">
          <canvas
            ref={canvasRef}
            width={canvasW}
            height={canvasH}
            className="rounded-xl shadow-2xl border border-border/10"
            style={{ width: 'min(380px, 80vw)', height: 'min(570px, 120vw)' }}
          />
          {/* Success badge */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="absolute -bottom-4 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-[10px] tracking-widest uppercase px-4 py-1.5 rounded-full shadow-lg"
          >
            Foto Selesai ✓
          </motion.div>
        </div>

        {/* Bottom action bar */}
        <div className="w-full max-w-md space-y-4 mt-4">
          {/* Photo thumbnails */}
          <div className="flex gap-2 justify-center">
            {Array.from({ length: n }).map((_, i) => (
              <div key={i} className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition-all ${photos[i] ? "border-emerald-400/60" : "border-border"}`}>
                {photos[i] ? (
                  <img src={photos[i]} alt={`Photo ${i + 1}`} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-muted flex items-center justify-center">
                    <span className="text-xs text-muted-foreground/40">{i + 1}</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Info row */}
          <div className="flex items-center justify-center gap-4 text-[10px] text-muted-foreground tracking-wide">
            <span>{template.name}</span>
            <span className="w-px h-3 bg-border" />
            <span>4R Portrait</span>
            <span className="w-px h-3 bg-border" />
            <span className="capitalize">{theme}</span>
          </div>

          {/* Action buttons — 3 columns */}
          <div className="flex gap-3">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleDownload}
              disabled={downloading}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-3 border border-border rounded-lg text-xs font-medium tracking-wide uppercase hover:bg-muted transition-colors disabled:opacity-50"
            >
              {downloading ? (
                <><RefreshCw className="h-3.5 w-3.5 animate-spin" />Menyimpan...</>
              ) : downloaded ? (
                <><Check className="h-3.5 w-3.5" />Tersimpan!</>
              ) : (
                <><Download className="h-3.5 w-3.5" />Simpan</>
              )}
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handlePrint}
              disabled={printing}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-3 bg-foreground text-primary-foreground rounded-lg text-xs font-medium tracking-wide uppercase hover:opacity-90 transition-opacity disabled:opacity-50"
            >
              {printing ? (
                <><RefreshCw className="h-3.5 w-3.5 animate-spin" />Mencetak...</>
              ) : printed ? (
                <><Check className="h-3.5 w-3.5" />Tercetak!</>
              ) : (
                <><Printer className="h-3.5 w-3.5" />Cetak</>
              )}
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onNext}
              className="flex-1 flex items-center justify-center gap-2 px-3 py-3 border border-border rounded-lg text-xs font-medium tracking-wide uppercase hover:bg-muted transition-colors"
            >
              Selesai
            </motion.button>
          </div>
          <p className="text-[10px] text-muted-foreground/50 text-center">Cetak langsung ke printer atau simpan ke perangkat</p>
        </div>
      </div>
    </motion.div>
  );
}
